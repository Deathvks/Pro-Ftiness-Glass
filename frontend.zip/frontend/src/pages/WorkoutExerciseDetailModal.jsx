/* frontend/src/pages/WorkoutExerciseDetailModal.jsx */
import React from 'react';
import { X, Dumbbell, Repeat, Clock, FileText } from 'lucide-react';
import { useTranslation } from 'react-i18next';
import GlassCard from '../components/GlassCard';
import ExerciseMedia from '../components/ExerciseMedia';
// --- INICIO DE LA MODIFICACIÓN ---
// Importamos el Spinner
import Spinner from '../components/Spinner';
// --- FIN DE LA MODIFICACIÓN ---

// --- INICIO DE LA MODIFICACIÓN ---
// Aceptamos la nueva prop 'isLoading'
const WorkoutExerciseDetailModal = ({ exercise, onClose, isLoading = false }) => {
// --- FIN DE LA MODIFICACIÓN ---

  // 1. Obtenemos 't' (para UI) y 'i18n' (para el idioma)
  const { t, i18n } = useTranslation(['exercise_names', 'exercises']);
  const lang = i18n.language.split('-')[0]; // 'es-ES' -> 'es'

  if (!exercise) return null;

  const details = exercise.exercise_details || {};

  // 2. Clave para el TÍTULO (esto funcionaba)
  const nameKey = details.name || exercise.name;

  /**
   * 3. Busca la descripción traducida...
   */
  const getTranslatedDescription = () => {
    if (!details.description) return null;

    // 1. Intentar idioma actual (ej: details.description_es)
    const langKey = `description_${lang}`;
    if (details[langKey]) {
      return details[langKey];
    }

    // 2. Fallback a inglés (ej: details.description_en)
    if (details.description_en) {
      return details.description_en;
    }

    // 3. Fallback al texto original
    return details.description;
  };

  // 4. Obtenemos la descripción con la nueva lógica
  //    (Se re-evaluará cuando 'exercise' cambie tras la carga)
  const description = getTranslatedDescription();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-[fade-in_0.3s_ease-out]"
      onClick={onClose}
    >
      <GlassCard
        className="relative w-full max-w-lg max-h-[90vh] m-4 p-6 overflow-y-auto animate-[fade-in-up_0.3s_ease-out]"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-text-secondary hover:text-text-primary hover:bg-white/10 transition"
        >
          <X size={24} />
        </button>

        {/* 5. Título: (siempre visible) */}
        <h2 className="text-2xl font-bold mb-4 pr-8">{t(nameKey, { ns: 'exercise_names' })}</h2>

        {/* 6. Media (Imagen/Video) */}
        <ExerciseMedia
          details={details}
          className="w-full mx-auto mb-4"
        />

        {/* 7. Información de la Rutina (siempre visible) */}
        <div className="space-y-3 mb-6">
          <h3 className="text-lg font-semibold text-text-secondary">
            {t('Plan de Hoy', { ns: 'exercises' })}
          </h3>
          <div className="flex items-center gap-4 p-3 bg-bg-secondary rounded-md border-glass-border">
            <Dumbbell size={20} className="text-accent" />
            <span className="font-medium">
              {t('{{count}} Series', { count: exercise.sets, ns: 'exercises' })}
            </span>
          </div>
          <div className="flex items-center gap-4 p-3 bg-bg-secondary rounded-md border-glass-border">
            <Repeat size={20} className="text-accent" />
            <span className="font-medium">
              {t('{{count}} Repeticiones', { count: exercise.reps, ns: 'exercises' })}
            </span>
          </div>
          <div className="flex items-center gap-4 p-3 bg-bg-secondary rounded-md border-glass-border">
            <Clock size={20} className="text-accent" />
            <span className="font-medium">
              {t('{{count}} seg. Descanso', { count: exercise.rest_seconds || 90, ns: 'exercises' })}
            </span>
          </div>
        </div>

        {/* --- INICIO DE LA MODIFICACIÓN --- */}
        {/* 8. Verificamos si está cargando O si existe la descripción */}
        {(isLoading || description) && (
          <div className="space-y-3">
            <h3 className="flex items-center gap-2 text-lg font-semibold text-text-secondary">
              <FileText size={20} className="text-accent" />
              {t('Descripción', { ns: 'exercises' })}
            </h3>
            
            {/* 9. Mostramos Spinner si isLoading es true */}
            {isLoading ? (
              <div className="flex justify-center items-center h-24">
                <Spinner />
              </div>
            ) : (
              /* 10. Renderizamos la descripción (si no está cargando y existe) */
              description && (
                <div
                  className="prose prose-sm prose-invert max-w-none text-text-primary leading-relaxed"
                  dangerouslySetInnerHTML={{ __html: description }}
                />
              )
            )}
          </div>
        )}
        {/* --- FIN DE LA MODIFICACIÓN --- */}
      </GlassCard>
    </div>
  );
};

export default WorkoutExerciseDetailModal;